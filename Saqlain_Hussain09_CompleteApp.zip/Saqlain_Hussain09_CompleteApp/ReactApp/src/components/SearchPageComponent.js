import React, { Component } from "react";
import ProductDataService from "../services/ProductDataService";

class SearchPageComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      productName: this.props.match.params.prodName,
      products: []
    };
  }

  componentWillMount() {
    ProductDataService.searchProductByName(this.state.productName).then(
      response =>
        this.setState({
          products: response.data
        })
    );
  }

  render() {
    return (
      <div className="container">
        <table className="table table-striped table-hover">
          <thead>
            <tr>
              <th>Product Id</th>
              <th>Product Name</th>
              <th>Quantity On Hand</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {this.state.products.map(product => (
              <tr key={product.productId}>
                <td>{product.productId}</td>
                <td>{product.productName}</td>
                <td>{product.quantityOnHand}</td>
                <td>{product.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default SearchPageComponent;
