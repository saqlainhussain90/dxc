package Day11;

public class Car extends Vehicle {
private String abs;
	public Car() {
		
	}

	public Car(String colour, int noOfWheels, String model) {
		super(colour, noOfWheels, model);
	}
	public void display()
	{
		System.out.println("This is a car");
	}

	public Car(String abs) {
		super();
		this.abs = abs;
	}

	public String getAbs() {
		return abs;
	}

	public void setAbs(String abs) {
		this.abs = abs;
	}

	@Override
	public String toString() {
		return "Car [abs=" + abs + ", getColour()=" + getColour() + ", getNoOfWheels()=" + getNoOfWheels()
				+ ", getModel()=" + getModel() + "]";
	}
	
}

