package com.dxc.jsp.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dxc.jsp.dao.QuestionDAO;
import com.dxc.jsp.dao.QuestionDAOImpl;
import com.dxc.jsp.model.Question;

/**
 * Servlet implementation class SecondQuestion1
 */
public class SecondQuestion1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String question2;
	String answer1;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecondQuestion1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Question> allQuestions = new ArrayList<Question>();
		Question question=new Question();
		QuestionDAO questionDAO=new QuestionDAOImpl();
		allQuestions=questionDAO.getAllQuestions();
		
		
		
		HttpSession session=request.getSession();
		session.setAttribute("question2", allQuestions.get(0).getQuestion());
	
		answer1=request.getParameter("answer1");
		session.setAttribute("answer1",answer1);
		
		
		session.setAttribute("ans2", allQuestions.get(0).getAnswer());
		
		RequestDispatcher dispatch=request.getRequestDispatcher("secondquestion.jsp");
		dispatch.forward(request, response);
	}

}
