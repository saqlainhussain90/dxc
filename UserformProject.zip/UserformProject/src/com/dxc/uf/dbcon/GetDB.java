package com.dxc.uf.dbcon;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetDB {
public static Connection getConnection() {
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	System.out.println("DriverLoaded");
	Connection connection=null;
	try {
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dxc","root","root");
	} catch (SQLException e) {
		e.printStackTrace();
	}
	System.out.println("DB Connected");
	return connection;
}
}
