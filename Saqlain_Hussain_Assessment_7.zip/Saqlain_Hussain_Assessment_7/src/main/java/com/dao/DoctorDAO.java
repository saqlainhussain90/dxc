package com.dao;

import java.util.List;

import com.model.Doctor;

public interface DoctorDAO {
		public Doctor getDoctor(int doctorId);
		public List<Doctor> getAllDoctor();
		public void addDoctor(Doctor doctor);
		public void deleteDoctor(int doctorId);
		public void updateDoctor(Doctor doctor);
		public boolean isDoctorExists(int doctorId);
		public List<String> getAllDoctorNames();
		public List<Doctor> getAllDoctors(String doctorName);
}
