package com.dxc.pasms.dao;

import java.util.List;

import com.dxc.pasms.Passenger;

public interface PassengerDAO {
	public Passenger getPassenger(int pnr);
	public List<Passenger>getAllPassenger();
	public void addPassenger(Passenger passenger);
	public void deletePassenger(int pnr);
	public void updatePassenger(Passenger passenger); 
}
