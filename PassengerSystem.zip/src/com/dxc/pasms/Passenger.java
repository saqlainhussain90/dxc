package com.dxc.pasms;

public class Passenger {
	private int pnr;
	private String passengerName;
	private String source;
	private int berth;
	public Passenger() {
		// TODO Auto-generated constructor stub
	}
	public Passenger(int pnr, String passengerName, String source, int berth) {
		super();
		this.pnr = pnr;
		this.passengerName = passengerName;
		this.source = source;
		this.berth = berth;
	}
	public int getPnr() {
		return pnr;
	}
	public void setPnr(int pnr) {
		this.pnr = pnr;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public int getBerth() {
		return berth;
	}
	public void setBerth(int berth) {
		this.berth = berth;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + berth;
		result = prime * result + ((passengerName == null) ? 0 : passengerName.hashCode());
		result = prime * result + pnr;
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Passenger other = (Passenger) obj;
		if (berth != other.berth)
			return false;
		if (passengerName == null) {
			if (other.passengerName != null)
				return false;
		} else if (!passengerName.equals(other.passengerName))
			return false;
		if (pnr != other.pnr)
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Passenger [pnr=" + pnr + ", passengerName=" + passengerName + ", source=" + source + ", berth=" + berth
				+ "]";
	}
	
}
