package com.univ.DAO;

import java.util.List;

import com.univ.model.Application;

public interface ApplicationDAO {
	public boolean addApplication(Application application);
	public boolean deleteApplication(int application_No);
	public List<Application> displayApplications();
}
