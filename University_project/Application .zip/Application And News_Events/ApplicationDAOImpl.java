package com.univ.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.mongodb.client.result.DeleteResult;
import com.univ.model.Application;
@Repository
public class ApplicationDAOImpl implements ApplicationDAO {
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public boolean addApplication(Application application) {
		mongoTemplate.save(application);
		return false;
	}

	@Override
	public boolean deleteApplication(int application_No) {
		Application application=new Application();
		application.setApplication_No(application_No);
		DeleteResult remove = mongoTemplate.remove(application);long deletedCount = remove.getDeletedCount();
		if (deletedCount==0)
			return false;
		else
			return true;
	}

	@Override
	public List<Application> displayApplications() {
		List<Application> findAll = mongoTemplate.findAll(Application.class);
		return findAll;
	}

}
