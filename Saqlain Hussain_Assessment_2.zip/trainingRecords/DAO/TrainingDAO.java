package com.dxc.trainingRecords.DAO;

import java.util.List;

import com.dxc.trainingRecords.model.*;

public interface TrainingDAO {

	
	public List<Training>getAllRecords();
public void updatePercentage();

}
