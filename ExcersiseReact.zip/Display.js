import React, { Component } from 'react';

class Display extends Component {
    render() {
         var value1 = function(itemText1) {return <div>{itemText1}</div>}
         var value2 = function(itemText2) {return <div>{itemText2}</div>}
         return <table cellpadding="20" cellspacing="25"  >
                <th>
                    <td>Company</td>
                    <td>Description</td>
                </th>
                <tr>
                    <td> {this.props.i1.map(value1)}</td>
                    <td> {this.props.i2.map(value2)}</td>
                </tr>
                </table>
        
    }
}

export default Display;