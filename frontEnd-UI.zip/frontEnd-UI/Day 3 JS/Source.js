function check()
    {
        var uname1=(document.getElementById("username").value);
            var uname2=(document.getElementById("password").value);
            a=uname2.length
            if(uname1.length==0 )
            {
                var span1=document.getElementById("span1")
                span1.innerHTML="<font color=green>enter the username</font>";
                return false;
            }
            
            
            
            else if (uname2.length == 0)
            {
                var span3=document.getElementById("span3")
                span3.innerHTML="enter the password";
                return false;

            }
           
            else {
                if(((uname2.charAt(0)) !== 'a') && ((uname2.length)<6  || (uname2.length)>12))
            {
                var span5=document.getElementById("span5")
           span5.innerHTML="Password should have 6-12 elements starting with a ";
           return false;

            }
           
            
           
           
                }
               
            
    }   