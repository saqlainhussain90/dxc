package day9;

import java.util.Scanner;

public class AddNumbers {
	int num1;
	int num2;
	Scanner sc=new Scanner(System.in);
	
	
	public void display()
	{
		System.out.println("Enter the first number");
		num1=sc.nextInt();
		System.out.println("Enter the second number");
		num2=sc.nextInt();
		
		if(num1<0 || num2<0 || (num1<0 && num2<0))
		{
			System.out.println("Negative numbers cant be added");
		}
		else
		{
			System.out.println("Sum of two numbers is :" +(num1+num2));
		}
		
		
			
	}
	public static void main(String args[])
	{
		
		AddNumbers a=new AddNumbers();
		a.display();
	}
	

}
