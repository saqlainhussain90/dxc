package day9;

import java.util.Scanner;

public class Vowel {
	char c;
	Scanner sc=new Scanner(System.in);
	
	
	public void display1()
	{
		System.out.println("Enter the character");
		c=sc.next().charAt(0);
		if(c == 'a' || c=='e' || c=='i' || c=='o' || c=='u' )
		{
			System.out.println("Entered character is a vowel");
		}
		else
		{
			System.out.println("Enter character is a Consonant");
		}
			
			
	}
	public static void main(String args[])
	{
		
		Vowel d=new Vowel();
		d.display1();
	}
	

}
