package day9;


import java.util.Scanner;

public class Swap1 {
	Scanner sc=new Scanner(System.in);
	int a
	int b
		
		public void display()
		{
			System.out.println("Enter the first number");
			a();
			

			System.out.println("Enter the second number");
			b();
	System.out.println("Numbers before swapping are : num1="+num1+ ",num2:" +num2);
			a=a+b;
			b=a-b;
			a=a-b;
			
	System.out.println("Numbers after swapping are : num1="+a+ ",num2:" +b);
	
		
		}
		public static void main(String args[])
		{
			Swap1 d=new Swap1();
			d.display();
		}
}
