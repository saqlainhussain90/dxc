package day9;

import java.util.Scanner;

public class LeapYear {

	Scanner sc=new Scanner(System.in);
	int year;
	
		
		public void display()
		{
			System.out.println("Enter the year");
			year=sc.nextInt();
			
		if(year % 400==0)
			System.out.println("Yes it is a leap year");
		else if(year % 100==0)
			System.out.println("It is not a leap year");
		else if(year % 4==0)
			System.out.println("Yes it is a leap year");
		else
			System.out.println("It is not a leap year");
		}
		
		public static void main(String args[])
		{
			LeapYear d=new LeapYear();
			d.display();
		}


}
